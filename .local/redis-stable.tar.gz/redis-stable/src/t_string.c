/*
 * Copyright (c) 2009-Present, Redis Ltd.
 * All rights reserved.
 *
 * Licensed under your choice of (a) the Redis Source Available License 2.0
 * (RSALv2); or (b) the Server Side Public License v1 (SSPLv1); or (c) the
 * GNU Affero General Public License v3 (AGPLv3).
 */

#include "server.h"
#include "cluster.h"
#include "xxhash.h"
#include <float.h>
#include <math.h> /* isnan(), isinf() */

/* XXH3 64-bit hash produces 16 hex characters when formatted */
#define DIGEST_HEX_LENGTH 16

/* Forward declarations */
int getGenericCommand(client *c);

/*-----------------------------------------------------------------------------
 * String Commands
 *----------------------------------------------------------------------------*/

static int checkStringLength(client *c, long long size, long long append) {
    if (mustObeyClient(c))
        return C_OK;
    /* 'uint64_t' cast is there just to prevent undefined behavior on overflow */
    long long total = (uint64_t)size + append;
    /* Test configured max-bulk-len representing a limit of the biggest string object,
     * and also test for overflow. */
    if (total > server.proto_max_bulk_len || total < size || total < append) {
        addReplyError(c,"string exceeds maximum allowed size (proto-max-bulk-len)");
        return C_ERR;
    }
    return C_OK;
}

/* The setGenericCommand() function implements the SET operation with different
 * options and variants. This function is called in order to implement the
 * following commands: SET, SETEX, PSETEX, SETNX, GETSET.
 *
 * 'flags' changes the behavior of the command (NX, XX, GET, IFEQ, IFNE, IFDEQ
 * or IFDNE - see below).
 *
 * 'expire' represents an expire to set in form of a Redis object as passed
 * by the user. It is interpreted according to the specified 'unit'.
 *
 * 'match_value' is a value to check against if any of IFEQ/IFNE/IFDEQ/IFDNE is
 * present.
 *
 * 'ok_reply' and 'abort_reply' is what the function will reply to the client
 * if the operation is performed, or when it is not because of NX or
 * XX flags.
 *
 * If ok_reply is NULL "+OK" is used.
 * If abort_reply is NULL, "$-1" is used. */

#define OBJ_NO_FLAGS 0
#define OBJ_SET_NX (1<<0)          /* Set if key not exists. */
#define OBJ_SET_XX (1<<1)          /* Set if key exists. */
#define OBJ_EX (1<<2)              /* Set if time in seconds is given */
#define OBJ_PX (1<<3)              /* Set if time in ms in given */
#define OBJ_KEEPTTL (1<<4)         /* Set and keep the ttl */
#define OBJ_SET_GET (1<<5)         /* Set if want to get key before set */
#define OBJ_EXAT (1<<6)            /* Set if timestamp in second is given */
#define OBJ_PXAT (1<<7)            /* Set if timestamp in ms is given */
#define OBJ_PERSIST (1<<8)         /* Set if we need to remove the ttl */
#define OBJ_SET_IFEQ (1<<9)        /* Set if value equals match value */
#define OBJ_SET_IFNE (1<<10)       /* Set if value does not equal match value */
#define OBJ_SET_IFDEQ (1<<11)      /* Set if current digest equals match digest */
#define OBJ_SET_IFDNE (1<<12)      /* Set if current digest does not equal match digest */

/* Forward declaration */
static int getExpireMillisecondsOrReply(client *c, robj *expire, int relative_ttl, int unit, long long *milliseconds);

/* Generic SET command family (SET, SETEX, PSETEX, SETNX)
 *
 * Arguments:
 *   valref: A pointer to the robj to be set. This argument may be updated by the function.
 *           The object is expected to have a refcount of 1, allowing its ownership to be
 *           transferred directly to the database to avoid making a copy. If needed, the
 *           function will replace *valref with a new allocation and increment its refcount
 *           so that both the database and the caller maintain valid references.
 */
void setGenericCommand(client *c, int flags, robj *key, robj **valref, robj *expire,
                       int unit, robj *match_value, robj *ok_reply, robj *abort_reply)
{
    long long milliseconds = 0; /* initialized to avoid any harmless warning */
    int found = 0;
    int setkey_flags = 0;
    int relative_ttl = (flags & (OBJ_EX|OBJ_PX)) != 0; /* EX/PX are relative; EXAT/PXAT are absolute. */

    if (expire && getExpireMillisecondsOrReply(c, expire, relative_ttl, unit, &milliseconds) != C_OK) {
        return;
    }

    if (flags & OBJ_SET_GET) {
        if (getGenericCommand(c) == C_ERR) return;
    }

    dictEntryLink link = NULL;
    found = (lookupKeyWriteWithLink(c->db,key,&link) != NULL);

    if ((flags & OBJ_SET_NX && found) ||
        (flags & (OBJ_SET_XX | OBJ_SET_IFEQ | OBJ_SET_IFDEQ) && !found))
    {
        if (!(flags & OBJ_SET_GET)) {
            addReply(c, abort_reply ? abort_reply : shared.null[c->resp]);
        }
        return;
    }

    /* Handle conditional set operations - only set if key is found and condition
     * is met - otherwise return nil. */
    if (found && (flags & (OBJ_SET_IFEQ | OBJ_SET_IFNE | OBJ_SET_IFDEQ | OBJ_SET_IFDNE))) {
        kvobj *current = lookupKeyRead(c->db, key);
        if (checkType(c, current, OBJ_STRING)) {
            return;
        }

        if (flags & OBJ_SET_IFEQ || flags & OBJ_SET_IFNE) {
            robj *current_decoded = getDecodedObject(current);
            int condition = (flags & OBJ_SET_IFEQ) ?
                            sdscmp(current_decoded->ptr, match_value->ptr) == 0 :
                            sdscmp(current_decoded->ptr, match_value->ptr) != 0;
            decrRefCount(current_decoded);
            if (!condition) {
                if (!(flags & OBJ_SET_GET)) {
                    addReply(c, abort_reply ? abort_reply : shared.null[c->resp]);
                }
                return;
            }
        } else if (flags & OBJ_SET_IFDEQ || flags & OBJ_SET_IFDNE) {
            if (validateHexDigest(c, match_value->ptr) != C_OK)
                return;

            sds current_digest = stringDigest(current);
            int condition = flags & OBJ_SET_IFDEQ ?
                            strcasecmp(current_digest, match_value->ptr) == 0 :
                            strcasecmp(current_digest, match_value->ptr) != 0;
            sdsfree(current_digest);
            if (!condition) {
                if (!(flags & OBJ_SET_GET)) {
                    addReply(c, abort_reply ? abort_reply : shared.null[c->resp]);
                }
                return;
            }
        }
    }

    /* If the expire time is already elapsed, we don't need to add the key,
     * but we still need to update the stats, and we also need to delete the
     * key if it exists.
     *
     * From stats perspective, we behave as if we inserted a new key (possibly
     * an overwrite) and later expired it, but from the per-key KSN observability,
     * we reflect what we've actually done in the db (deletion of old key, and
     * no insertion of new one), so we don't confuse modules. */
    if (expire && checkAlreadyExpired(milliseconds)) {
        if (found) {
            dbDelete(c->db, key);
            robj *aux = server.lazyfree_lazy_server_del ? shared.unlink : shared.del;
            rewriteClientCommandVector(c, 2, aux, key);
            keyModified(c, c->db, key, NULL, 1);
            notifyKeyspaceEvent(NOTIFY_GENERIC, "del", key, c->db->id);
            server.dirty++;
        }
        server.stat_expiredkeys++;
        if (!(flags & OBJ_SET_GET)) {
            addReply(c, ok_reply ? ok_reply : shared.ok);
        }
        return;
    }

    /* When expire is not NULL, we avoid deleting the TTL so it can be updated later instead of being deleted and then created again. */
    setkey_flags |= ((flags & OBJ_KEEPTTL) || expire) ? SETKEY_KEEPTTL : 0;
    setkey_flags |= found ? SETKEY_ALREADY_EXIST : SETKEY_DOESNT_EXIST;

    setKeyByLink(c, c->db, key, valref, setkey_flags, &link);
    /* If there's an expiration, setExpireByLink may reallocate the object.
     * We must update valref to reflect the new object if that happens. */
    if (expire) *valref = setExpireByLink(c, c->db, key->ptr, milliseconds, link);
    /* The client still holds a reference to the original object via c->argv[i],
     * and will call decrRefCount() at the end of call(). We increment the refcount
     * from 1 to 2 to ensure both DB and client have valid references. */
    incrRefCount(*valref); /* 1->2 */

    server.dirty++;
    notifyKeyspaceEvent(NOTIFY_STRING,"set",key,c->db->id);

    if (expire) {
        /* Propagate as SET Key Value PXAT millisecond-timestamp if there is
         * EX/PX/EXAT flag. */
        if (!(flags & OBJ_PXAT)) {
            robj *milliseconds_obj = createStringObjectFromLongLong(milliseconds);
            /* If command is exactly "SET key value EX/PX/EXAT ttl", we can just
             * replace the expire type and value in-place. Otherwise, we need to
             * rewrite the entire command to strip extra flags (NX, XX, GET, etc). */
            if ((c->cmd->proc == setCommand) && c->argc == 5) {
                rewriteClientCommandArgument(c, 3, shared.pxat);
                rewriteClientCommandArgument(c, 4, milliseconds_obj);
            } else {
                rewriteClientCommandVector(c, 5, shared.set, key, *valref, shared.pxat, milliseconds_obj);
            }
            decrRefCount(milliseconds_obj);
        }
        notifyKeyspaceEvent(NOTIFY_GENERIC,"expire",key,c->db->id);
    }

    if (!(flags & OBJ_SET_GET)) {
        addReply(c, ok_reply ? ok_reply : shared.ok);
    }

    /* Propagate without the GET argument (Isn't needed if we had expire since in that case we completely re-written the command argv) */
    if ((flags & OBJ_SET_GET) && !expire) {
        for (int j = c->argc - 1; j >= 3; j--) {
            char *a = c->argv[j]->ptr;
            /* Skip GET which may be repeated multiple times. */
            if ((a[0] == 'g' || a[0] == 'G') &&
                (a[1] == 'e' || a[1] == 'E') &&
                (a[2] == 't' || a[2] == 'T') && a[3] == '\0')
            {
                rewriteClientCommandArgument(c, j, NULL);
            }
        }
    }
}

/*
 * Extract the `expire` argument of a given command as an absolute timestamp in milliseconds.
 *
 * "client" is the client that sent the `expire` argument.
 * "expire" is the `expire` argument to be extracted.
 * "relative_ttl" is true when the value is a relative TTL (EX/PX),
 *                false when it is an absolute timestamp (EXAT/PXAT).
 * "unit" is the original unit of the given `expire` argument (e.g. UNIT_SECONDS).
 * "milliseconds" is output argument.
 *
 * If return C_OK, "milliseconds" output argument will be set to the resulting absolute timestamp.
 * If return C_ERR, an error reply has been added to the given client.
 */
static int getExpireMillisecondsOrReply(client *c, robj *expire, int relative_ttl, int unit, long long *milliseconds) {
    int ret = getLongLongFromObjectOrReply(c, expire, milliseconds, NULL);
    if (ret != C_OK) {
        return ret;
    }

    if (*milliseconds <= 0 || (unit == UNIT_SECONDS && *milliseconds > LLONG_MAX / 1000)) {
        /* Negative value provided or multiplication is gonna overflow. */
        addReplyErrorExpireTime(c);
        return C_ERR;
    }

    if (unit == UNIT_SECONDS) *milliseconds *= 1000;

    if (relative_ttl) {
        *milliseconds += commandTimeSnapshot();
    }

    if (*milliseconds <= 0) {
        /* Overflow detected. */
        addReplyErrorExpireTime(c);
        return C_ERR;
    }

    return C_OK;
}

#define COMMAND_GET 0
#define COMMAND_SET 1
#define COMMAND_MSETEX 2

/* Extended string command arguments structure */
typedef struct {
    int flags;
    int unit;
    int expire_pos;  /* Position of EX/PX flag for replication rewriting */
    robj *expire;
    robj *match_value; /* For IFEQ/IFNE/IFDEQ/IFDNE conditions */
} extendedStringArgs;

/*
 * The parseExtendedStringArgumentsOrReply() function performs the common validation for extended
 * string arguments used in SET, GET and MSETEX commands.
 *
 * Get specific commands - PERSIST/DEL
 * Set specific commands - XX/NX/GET/IFEQ/IFNE/IFDEQ/IFDNE
 * Common commands - EX/EXAT/PX/PXAT/KEEPTTL
 *
 * Function takes pointers to client, start_pos for where to begin parsing, extendedStringArgs
 * structure to populate, and command_type which can be COMMAND_GET, COMMAND_SET, or COMMAND_MSETEX.
 *
 * If there are any syntax violations C_ERR is returned else C_OK is returned.
 *
 * The args structure is updated upon parsing the arguments. Unit and expire are updated if there are any
 * EX/EXAT/PX/PXAT arguments. Unit is updated to millisecond if PX/PXAT is set.
 * match_value is updated if any of IFEQ/IFNE/IFDEQ/IFDNE is set.
 */
int parseExtendedStringArgumentsOrReply(client *c, int start_pos, extendedStringArgs *args, int command_type) {
    /* Initialize arguments to defaults */
    memset(args, 0, sizeof(*args));
    args->expire_pos = -1;
    args->unit = UNIT_SECONDS;

    int j = start_pos;
   /* We can have either none or exactly one of these conditionals as they are
     * mutually exclusive. We'll make sure to check if none of the other flags
     * are already set if we are going to set one of them. This is done via the
     * check:
     *
     * if (opt == OBJ_SET_XXX && !(*flags & (cond_mut_excl & ~OBJ_SET_XXX)))
     *
     * A bit ugly - but concise.
     */
    int cond_mut_excl = OBJ_SET_NX | OBJ_SET_XX | OBJ_SET_IFEQ | OBJ_SET_IFNE |
                        OBJ_SET_IFDEQ | OBJ_SET_IFDNE;
    for (; j < c->argc; j++) {
        char *opt = c->argv[j]->ptr;
        robj *next = (j == c->argc-1) ? NULL : c->argv[j+1];

        if ((opt[0] == 'n' || opt[0] == 'N') &&
            (opt[1] == 'x' || opt[1] == 'X') && opt[2] == '\0' &&
            !(args->flags & OBJ_SET_XX) && (command_type == COMMAND_SET || command_type == COMMAND_MSETEX))
        {
            args->flags |= OBJ_SET_NX;
        } else if ((opt[0] == 'x' || opt[0] == 'X') &&
                   (opt[1] == 'x' || opt[1] == 'X') && opt[2] == '\0' &&
                   !(args->flags & OBJ_SET_NX) && (command_type == COMMAND_SET || command_type == COMMAND_MSETEX))
        {
            args->flags |= OBJ_SET_XX;
        } else if ((opt[0] == 'g' || opt[0] == 'G') &&
                   (opt[1] == 'e' || opt[1] == 'E') &&
                   (opt[2] == 't' || opt[2] == 'T') && opt[3] == '\0' &&
                   (command_type == COMMAND_SET))
        {
            args->flags |= OBJ_SET_GET;
        } else if (!strcasecmp(opt, "KEEPTTL") && !(args->flags & OBJ_PERSIST) &&
            !(args->flags & OBJ_EX) && !(args->flags & OBJ_EXAT) &&
            !(args->flags & OBJ_PX) && !(args->flags & OBJ_PXAT) &&
            (command_type == COMMAND_SET || command_type == COMMAND_MSETEX))
        {
            args->flags |= OBJ_KEEPTTL;
        } else if (!strcasecmp(opt,"PERSIST") && (command_type == COMMAND_GET) &&
               !(args->flags & OBJ_EX) && !(args->flags & OBJ_EXAT) &&
               !(args->flags & OBJ_PX) && !(args->flags & OBJ_PXAT) &&
               !(args->flags & OBJ_KEEPTTL))
        {
            args->flags |= OBJ_PERSIST;
        } else if ((opt[0] == 'e' || opt[0] == 'E') &&
                   (opt[1] == 'x' || opt[1] == 'X') && opt[2] == '\0' &&
                   !(args->flags & OBJ_KEEPTTL) && !(args->flags & OBJ_PERSIST) &&
                   !(args->flags & OBJ_EXAT) && !(args->flags & OBJ_PX) &&
                   !(args->flags & OBJ_PXAT) && next)
        {
            args->flags |= OBJ_EX;
            args->expire = next;
            args->expire_pos = j;
            j++;
        } else if ((opt[0] == 'p' || opt[0] == 'P') &&
                   (opt[1] == 'x' || opt[1] == 'X') && opt[2] == '\0' &&
                   !(args->flags & OBJ_KEEPTTL) && !(args->flags & OBJ_PERSIST) &&
                   !(args->flags & OBJ_EX) && !(args->flags & OBJ_EXAT) &&
                   !(args->flags & OBJ_PXAT) && next)
        {
            args->flags |= OBJ_PX;
            args->unit = UNIT_MILLISECONDS;
            args->expire = next;
            args->expire_pos = j;
            j++;
        } else if ((opt[0] == 'e' || opt[0] == 'E') &&
                   (opt[1] == 'x' || opt[1] == 'X') &&
                   (opt[2] == 'a' || opt[2] == 'A') &&
                   (opt[3] == 't' || opt[3] == 'T') && opt[4] == '\0' &&
                   !(args->flags & OBJ_KEEPTTL) && !(args->flags & OBJ_PERSIST) &&
                   !(args->flags & OBJ_EX) && !(args->flags & OBJ_PX) &&
                   !(args->flags & OBJ_PXAT) && next)
        {
            args->flags |= OBJ_EXAT;
            args->expire = next;
            j++;
        } else if ((opt[0] == 'p' || opt[0] == 'P') &&
                   (opt[1] == 'x' || opt[1] == 'X') &&
                   (opt[2] == 'a' || opt[2] == 'A') &&
                   (opt[3] == 't' || opt[3] == 'T') && opt[4] == '\0' &&
                   !(args->flags & OBJ_KEEPTTL) && !(args->flags & OBJ_PERSIST) &&
                   !(args->flags & OBJ_EX) && !(args->flags & OBJ_EXAT) &&
                   !(args->flags & OBJ_PX) && next)
        {
            args->flags |= OBJ_PXAT;
            args->unit = UNIT_MILLISECONDS;
            args->expire = next;
            j++;
        } else if (!strcasecmp(opt, "ifeq") && next &&
                   !(args->flags & (cond_mut_excl & ~OBJ_SET_IFEQ)) &&
                   (command_type == COMMAND_SET))
        {
            args->flags |= OBJ_SET_IFEQ;
            args->match_value = next;
            j++;
        } else if (!strcasecmp(opt, "ifne") && next &&
                   !(args->flags & (cond_mut_excl & ~OBJ_SET_IFNE)) &&
                   (command_type == COMMAND_SET))
        {
            args->flags |= OBJ_SET_IFNE;
            args->match_value = next;
            j++;
        } else if (!strcasecmp(opt, "ifdeq") && next &&
                   !(args->flags & (cond_mut_excl & ~OBJ_SET_IFDEQ)) &&
                   (command_type == COMMAND_SET))
        {
            args->flags |= OBJ_SET_IFDEQ;
            args->match_value = next;
            j++;
        } else if (!strcasecmp(opt, "ifdne") && next &&
                   !(args->flags & (cond_mut_excl & ~OBJ_SET_IFDNE)) &&
                   (command_type == COMMAND_SET))
        {
            args->flags |= OBJ_SET_IFDNE;
            args->match_value = next;
            j++;
        } else {
            addReplyErrorObject(c,shared.syntaxerr);
            return C_ERR;
        }
    }
    return C_OK;
}

/* SET key value [NX] [XX] [KEEPTTL] [GET] [EX <seconds>] [PX <milliseconds>]
 *     [EXAT <seconds-timestamp>][PXAT <milliseconds-timestamp>]
 *     [IFEQ <match-value>|IFNE <match-value>|IFDEQ <match-digest>|
 *      IFDNE <match-digest>]*/
void setCommand(client *c) {
    extendedStringArgs args;

    if (parseExtendedStringArgumentsOrReply(c, 3, &args, COMMAND_SET) != C_OK) {
        return;
    }

    c->argv[2] = tryObjectEncoding(c->argv[2]);
    setGenericCommand(c, args.flags, c->argv[1], &(c->argv[2]), args.expire, args.unit, args.match_value, NULL, NULL);
}

void setnxCommand(client *c) {
    c->argv[2] = tryObjectEncoding(c->argv[2]);
    setGenericCommand(c, OBJ_SET_NX, c->argv[1], &(c->argv[2]), NULL, 0, NULL, shared.cone, shared.czero);
}

void setexCommand(client *c) {
    c->argv[3] = tryObjectEncoding(c->argv[3]);
    setGenericCommand(c, OBJ_EX, c->argv[1], &(c->argv[3]), c->argv[2], UNIT_SECONDS, NULL, NULL, NULL);
}

void psetexCommand(client *c) {
    c->argv[3] = tryObjectEncoding(c->argv[3]);
    setGenericCommand(c, OBJ_PX, c->argv[1], &(c->argv[3]), c->argv[2], UNIT_MILLISECONDS, NULL, NULL, NULL);
}

int getGenericCommand(client *c) {
    kvobj *o;

    if ((o = lookupKeyReadOrReply(c, c->argv[1], shared.null[c->resp])) == NULL)
        return C_OK;

    if (checkType(c,o,OBJ_STRING)) {
        return C_ERR;
    }

    addReplyBulk(c,o);
    return C_OK;
}

void getCommand(client *c) {
    getGenericCommand(c);
}

/*
 * GETEX <key> [PERSIST][EX seconds][PX milliseconds][EXAT seconds-timestamp][PXAT milliseconds-timestamp]
 *
 * The getexCommand() function implements extended options and variants of the GET command. Unlike GET
 * command this command is not read-only.
 *
 * The default behavior when no options are specified is same as GET and does not alter any TTL.
 *
 * Only one of the below options can be used at a given time.
 *
 * 1. PERSIST removes any TTL associated with the key.
 * 2. EX Set expiry TTL in seconds.
 * 3. PX Set expiry TTL in milliseconds.
 * 4. EXAT Same like EX instead of specifying the number of seconds representing the TTL
 *      (time to live), it takes an absolute Unix timestamp
 * 5. PXAT Same like PX instead of specifying the number of milliseconds representing the TTL
 *      (time to live), it takes an absolute Unix timestamp
 *
 * Command would either return the bulk string, error or nil.
 */
void getexCommand(client *c) {
    extendedStringArgs args;

    if (parseExtendedStringArgumentsOrReply(c, 2, &args, COMMAND_GET) != C_OK) {
        return;
    }

    kvobj *o;

    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.null[c->resp])) == NULL)
        return;

    if (checkType(c,o,OBJ_STRING)) {
        return;
    }

    /* Validate the expiration time value first */
    long long milliseconds = 0;
    int relative_ttl = (args.flags & (OBJ_EX|OBJ_PX)) != 0; /* EX/PX are relative; EXAT/PXAT are absolute. */
    if (args.expire && getExpireMillisecondsOrReply(c, args.expire, relative_ttl, args.unit, &milliseconds) != C_OK) {
        return;
    }

    /* We need to do this before we expire the key or delete it */
    addReplyBulk(c,o);

    /* This command is never propagated as is. It is either propagated as PEXPIRE[AT],DEL,UNLINK or PERSIST.
     * This why it doesn't need special handling in feedAppendOnlyFile to convert relative expire time to absolute one. */
    if (((args.flags & OBJ_PXAT) || (args.flags & OBJ_EXAT)) && checkAlreadyExpired(milliseconds)) {
        /* When PXAT/EXAT absolute timestamp is specified, there can be a chance that timestamp
         * has already elapsed so delete the key in that case. */
        int deleted = dbGenericDelete(c->db, c->argv[1], server.lazyfree_lazy_expire, DB_FLAG_KEY_EXPIRED);
        serverAssert(deleted);
        robj *aux = server.lazyfree_lazy_expire ? shared.unlink : shared.del;
        rewriteClientCommandVector(c,2,aux,c->argv[1]);
        keyModified(c, c->db, c->argv[1], NULL, 1);
        notifyKeyspaceEvent(NOTIFY_GENERIC, "del", c->argv[1], c->db->id);
        server.dirty++;
    } else if (args.expire) {
        o = setExpire(c,c->db,c->argv[1],milliseconds);
        /* Propagate as PXEXPIREAT millisecond-timestamp if there is
         * EX/PX/EXAT/PXAT flag and the key has not expired. */
        robj *milliseconds_obj = createStringObjectFromLongLong(milliseconds);
        rewriteClientCommandVector(c,3,shared.pexpireat,c->argv[1],milliseconds_obj);
        decrRefCount(milliseconds_obj);
        keyModified(c, c->db, c->argv[1], o, 1);
        notifyKeyspaceEvent(NOTIFY_GENERIC,"expire",c->argv[1],c->db->id);
        server.dirty++;
    } else if (args.flags & OBJ_PERSIST) {
        if (removeExpire(c->db, c->argv[1])) {
            keyModified(c, c->db, c->argv[1], o, 1);
            rewriteClientCommandVector(c, 2, shared.persist, c->argv[1]);
            notifyKeyspaceEvent(NOTIFY_GENERIC,"persist",c->argv[1],c->db->id);
            server.dirty++;
        }
    }
}

void getdelCommand(client *c) {
    if (getGenericCommand(c) == C_ERR) return;
    if (dbSyncDelete(c->db, c->argv[1])) {
        /* Propagate as DEL command */
        rewriteClientCommandVector(c,2,shared.del,c->argv[1]);
        keyModified(c, c->db, c->argv[1], NULL, 1);
        notifyKeyspaceEvent(NOTIFY_GENERIC, "del", c->argv[1], c->db->id);
        server.dirty++;
    }
}

void getsetCommand(client *c) {
    if (getGenericCommand(c) == C_ERR) return;
    c->argv[2] = tryObjectEncoding(c->argv[2]);
    setKey(c, c->db, c->argv[1], &c->argv[2], 0);
    incrRefCount(c->argv[2]);
    notifyKeyspaceEvent(NOTIFY_STRING,"set",c->argv[1],c->db->id);
    server.dirty++;

    /* Propagate as SET command */
    rewriteClientCommandArgument(c,0,shared.set);
}

void setrangeCommand(client *c) {
    int64_t oldLen = -1, newLen;
    long offset;
    sds value = c->argv[3]->ptr;
    const size_t value_len = sdslen(value);

    if (getLongFromObjectOrReply(c,c->argv[2],&offset,NULL) != C_OK)
        return;

    if (offset < 0) {
        addReplyError(c,"offset is out of range");
        return;
    }

    dictEntryLink link;
    kvobj *kv = lookupKeyWriteWithLink(c->db, c->argv[1], &link);
    if (kv == NULL) {
        /* Return 0 when setting nothing on a non-existing string */
        if (value_len == 0) {
            addReply(c,shared.czero);
            return;
        }

        /* Return when the resulting string exceeds allowed size */
        if (checkStringLength(c,offset,value_len) != C_OK)
            return;

        newLen = offset+value_len;
        robj *o = createObject(OBJ_STRING,sdsnewlen(NULL, newLen));
        kv = dbAddByLink(c->db, c->argv[1], &o, &link);
    } else {
        /* Key exists, check type */
        if (checkType(c,kv,OBJ_STRING))
            return;

        /* Return existing string length when setting nothing */
        oldLen = stringObjectLen(kv);
        if (value_len == 0) {
            addReplyLongLong(c, oldLen);
            return;
        }

        /* Return when the resulting string exceeds allowed size */
        if (checkStringLength(c,offset,value_len) != C_OK)
            return;

        /* Create a copy when the object is shared or encoded. */
        kv = dbUnshareStringValueByLink(c->db, c->argv[1], kv, link);

        newLen = max(oldLen, (int64_t) (offset + value_len));
        updateKeysizesHist(c->db, OBJ_STRING, oldLen, newLen);            
    }

    if (value_len > 0) {
        size_t oldsize = 0;
        if (server.memory_tracking_enabled)
            oldsize = kvobjAllocSize(kv);
        kv->ptr = sdsgrowzero(kv->ptr,offset+value_len);
        if (server.memory_tracking_enabled)
            updateSlotAllocSize(c->db, getKeySlot(c->argv[1]->ptr), kv, oldsize, kvobjAllocSize(kv));
        memcpy((char*)kv->ptr+offset,value,value_len);
        keyModified(c,c->db,c->argv[1],kv,1);
        notifyKeyspaceEvent(NOTIFY_STRING,
            "setrange",c->argv[1],c->db->id);
        server.dirty++;
    }

    addReplyLongLong(c,newLen);
}

void getrangeCommand(client *c) {
    kvobj *o;
    long long start, end;
    char *str, llbuf[32];
    size_t strlen;

    if (getLongLongFromObjectOrReply(c,c->argv[2],&start,NULL) != C_OK)
        return;
    if (getLongLongFromObjectOrReply(c,c->argv[3],&end,NULL) != C_OK)
        return;
    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.emptybulk)) == NULL ||
        checkType(c,o,OBJ_STRING)) return;

    if (o->encoding == OBJ_ENCODING_INT) {
        str = llbuf;
        strlen = ll2string(llbuf,sizeof(llbuf),(long)o->ptr);
    } else {
        str = o->ptr;
        strlen = sdslen(str);
    }

    /* Convert negative indexes */
    if (start < 0 && end < 0 && start > end) {
        addReply(c,shared.emptybulk);
        return;
    }
    if (start < 0) start = strlen+start;
    if (end < 0) end = strlen+end;
    if (start < 0) start = 0;
    if (end < 0) end = 0;
    if ((unsigned long long)end >= strlen) end = strlen-1;

    /* Precondition: end >= 0 && end < strlen, so the only condition where
     * nothing can be returned is: start > end. */
    if (start > end || strlen == 0) {
        addReply(c,shared.emptybulk);
    } else {
        addReplyBulkCBuffer(c,(char*)str+start,end-start+1);
    }
}

/* Batch size for intra-command key prefetching. */
#define PREFETCH_BATCH_SIZE 16

/* Pick the next prefetch batch starting at argv[start] and warm it via
 * dictPrefetchKeys. 'stride' is 1 for keys-only args (MGET) or 2 for
 * key/value pairs (MSET). Returns the chosen batch size in items. */
static int prefetchKeysBatch(client *c, int slot, int start, int stride) {
    int batch = (c->argc - start) / stride;

    /* If at least two full batches remain, take one; otherwise fall
     * through with batch = remaining keys, doing them in one go. */
    if (batch >= PREFETCH_BATCH_SIZE*2) batch = PREFETCH_BATCH_SIZE;

    dict *d = kvstoreGetDict(c->db->keys, slot);
    if (d != NULL && dictSize(d) > 0) {
        void *keys[PREFETCH_BATCH_SIZE*2];
        dict *dicts[PREFETCH_BATCH_SIZE*2];
        for (int k = 0; k < batch; k++) {
            keys[k]  = c->argv[start + k * stride]->ptr;
            dicts[k] = d;
        }
        dictPrefetchKeys(dicts, keys, batch);
    }
    return batch;
}

void mgetCommand(client *c) {
    int numkeys = c->argc - 1;

    addReplyArrayLen(c, numkeys);

    /* MGET requires all keys in the same slot in cluster mode. Reuse the
     * slot already computed by the cross-command batching path when
     * available, otherwise fall back to recomputing from argv[1]. */
    int slot = 0;
    if (server.cluster_enabled) {
        pendingCommand *pcmd = c->current_pending_cmd;
        slot = (pcmd && pcmd->slot != INVALID_CLUSTER_SLOT) ?
                pcmd->slot : getKeySlot(c->argv[1]->ptr);
    }

    /* Decide whether to prefetch within this command. Skip if disabled by
     * config (prefetch_batch_max_size == 0), or if the cross-command batch
     * path already warmed our keys — running both paths would just contend
     * for cache bandwidth. */
    int already_prefetched = c->current_pending_cmd &&
        (c->current_pending_cmd->flags & PENDING_CMD_KEYS_PREFETCHED);
    int do_prefetch = server.prefetch_batch_max_size && !already_prefetched && numkeys > 1;

    int j = 1;
    while (j < c->argc) {
        /* If prefetching, take one batch; otherwise take all items. */
        int batch = do_prefetch ? prefetchKeysBatch(c, slot, j, 1) : c->argc - j;

        for (int k = 0; k < batch; k++) {
            kvobj *o = lookupKeyRead(c->db, c->argv[j + k]);
            if (o == NULL || o->type != OBJ_STRING)
                addReplyNull(c);
            else
                addReplyBulk(c, o);
        }
        j += batch;
    }
}

void msetGenericCommand(client *c, int nx) {
    if ((c->argc % 2) == 0) {
        addReplyErrorArity(c);
        return;
    }

    int numkeys = (c->argc - 1) / 2;

    /* Same gating as mgetCommand, see comment there. */
    int slot = 0;
    if (server.cluster_enabled) {
        pendingCommand *pcmd = c->current_pending_cmd;
        slot = (pcmd && pcmd->slot != INVALID_CLUSTER_SLOT) ?
                pcmd->slot : getKeySlot(c->argv[1]->ptr);
    }
    int already_prefetched = c->current_pending_cmd &&
        (c->current_pending_cmd->flags & PENDING_CMD_KEYS_PREFETCHED);
    int do_prefetch = server.prefetch_batch_max_size && !already_prefetched && numkeys > 1;

    /* Handle the NX flag. The MSETNX semantic is to return zero and don't
     * set anything if at least one key already exists. */
    if (nx) {
        int j = 1;
        while (j < c->argc) {
            /* If prefetching, take one batch; otherwise take all items. */
            int batch = do_prefetch ? prefetchKeysBatch(c, slot, j, 2)
                                    : (c->argc - j) / 2;
            for (int k = 0; k < batch; k++) {
                if (lookupKeyWrite(c->db, c->argv[j + k * 2]) != NULL) {
                    addReply(c, shared.czero);
                    return;
                }
            }
            j += batch * 2;
        }
    }

    /* If nx is set, the NX loop above already prefetched. */
    do_prefetch = do_prefetch && !nx;

    int j = 1;
    while (j < c->argc) {
        int batch = do_prefetch ? prefetchKeysBatch(c, slot, j, 2)
                                : (c->argc - j) / 2;
        for (int k = 0; k < batch; k++) {
            int i = j + k * 2;
            c->argv[i + 1] = tryObjectEncoding(c->argv[i + 1]);
            setKey(c, c->db, c->argv[i], &(c->argv[i + 1]), 0);
            incrRefCount(c->argv[i + 1]);
            notifyKeyspaceEvent(NOTIFY_STRING, "set", c->argv[i], c->db->id);
        }
        j += batch * 2;
    }
    server.dirty += numkeys;
    addReply(c, nx ? shared.cone : shared.ok);
}

void msetCommand(client *c) {
    msetGenericCommand(c,0);
}

void msetnxCommand(client *c) {
    msetGenericCommand(c,1);
}

void msetexCommand(client *c) {
    /* Parse numkeys parameter */
    long kv_count;
    if (getRangeLongFromObjectOrReply(c, c->argv[1], 1, INT_MAX,
        &kv_count, "invalid numkeys value") != C_OK)
    {
        return;
    }

    /* Validate we have enough arguments: command + numkeys + (key-value pairs) * 2
     * Be careful to avoid overflow when calculating kv_count * 2 */
    if ((long long)kv_count * 2 + 2 > c->argc) {
        addReplyError(c, "wrong number of key-value pairs");
        return;
    }

    extendedStringArgs args;
    if (parseExtendedStringArgumentsOrReply(c, kv_count * 2 + 2, &args, COMMAND_MSETEX) != C_OK) {
        return;
    }

    /* Validate the expiration time value first */
    long long milliseconds = 0;
    int relative_ttl = (args.flags & (OBJ_EX|OBJ_PX)) != 0; /* EX/PX are relative; EXAT/PXAT are absolute. */
    if (args.expire && getExpireMillisecondsOrReply(c, args.expire, relative_ttl, args.unit, &milliseconds) != C_OK) {
        return;
    }

    if (args.flags & (OBJ_SET_NX | OBJ_SET_XX)) {
        /* Check NX/XX conditions for each key - pattern from setGenericCommand */
        for (int j = 0; j < kv_count; j++) {
            int key_idx = (j * 2) + 2;
            robj *found = lookupKeyWrite(c->db, c->argv[key_idx]);

            if ((args.flags & OBJ_SET_NX && found) ||
                (args.flags & OBJ_SET_XX && !found))
            {
                addReply(c, shared.czero);
                return;
            }
        }
    }

    /* Set all key-value pairs */
    for (int j = 0; j < kv_count; j++) {
        int key_idx = (j * 2) + 2;
        int val_idx = key_idx + 1;

        c->argv[val_idx] = tryObjectEncoding(c->argv[val_idx]);

        /* Handle KEEPTTL - preserve existing TTL */
        int setkey_flags = 0;
        if (args.flags & OBJ_KEEPTTL) {
            setkey_flags |= SETKEY_KEEPTTL;
        }

        setKey(c, c->db, c->argv[key_idx], &(c->argv[val_idx]), setkey_flags);
        incrRefCount(c->argv[val_idx]);

        /* Set expiration for each key (but not for KEEPTTL) */
        if (args.expire && !(args.flags & OBJ_KEEPTTL)) {
            setExpire(c, c->db, c->argv[key_idx], milliseconds);
            notifyKeyspaceEvent(NOTIFY_GENERIC,"expire",c->argv[key_idx],c->db->id);
        }
        notifyKeyspaceEvent(NOTIFY_STRING,"set",c->argv[key_idx],c->db->id);
    }

    /* Handle replication rewriting for relative expiration times */
    if (args.expire && !(args.flags & OBJ_PXAT) && !(args.flags & OBJ_EXAT) && args.expire_pos != -1) {
        /* Convert EX/PX (relative) to PXAT (absolute) for consistent replication */
        robj *milliseconds_obj = createStringObjectFromLongLong(milliseconds);
        rewriteClientCommandArgument(c, args.expire_pos, shared.pxat);
        rewriteClientCommandArgument(c, args.expire_pos + 1, milliseconds_obj);
        decrRefCount(milliseconds_obj);
    }

    server.dirty += kv_count;
    addReply(c, shared.cone);
}

void incrDecrCommand(client *c, long long incr) {
    long long value, oldvalue;
    robj *new;
    dictEntryLink link;
    kvobj *o = lookupKeyWriteWithLink(c->db, c->argv[1], &link);
    if (checkType(c,o,OBJ_STRING)) return;
    if (getLongLongFromObjectOrReply(c,o,&value,NULL) != C_OK) return;

    oldvalue = value;
    if ((incr < 0 && oldvalue < 0 && incr < (LLONG_MIN-oldvalue)) ||
        (incr > 0 && oldvalue > 0 && incr > (LLONG_MAX-oldvalue))) {
        addReplyError(c,"increment or decrement would overflow");
        return;
    }
    value += incr;

    if (o && o->refcount == 1 && o->encoding == OBJ_ENCODING_INT &&
        value >= LONG_MIN && value <= LONG_MAX)
    {
        new = o;
        o->ptr = (void*)((long)value);
        updateKeysizesHist(c->db, OBJ_STRING,
                           (int64_t) sdigits10(oldvalue),
                           (int64_t) sdigits10(value));
    } else {
        new = createStringObjectFromLongLongForValue(value);
        if (o) {
            /* replace value in db and also update keysizes hist */
            dbReplaceValueWithLink(c->db, c->argv[1], &new, link);
        } else {
            /* Add new key to db and also update keysizes hist */
            dbAddByLink(c->db, c->argv[1], &new, &link);
        }
    }
    addReplyLongLongFromStr(c,new);
    keyModified(c,c->db,c->argv[1],new,1);
    notifyKeyspaceEvent(NOTIFY_STRING,"incrby",c->argv[1],c->db->id);
    server.dirty++;
}

void incrCommand(client *c) {
    incrDecrCommand(c,1);
}

void decrCommand(client *c) {
    incrDecrCommand(c,-1);
}

void incrbyCommand(client *c) {
    long long incr;

    if (getLongLongFromObjectOrReply(c, c->argv[2], &incr, NULL) != C_OK) return;
    incrDecrCommand(c,incr);
}

void decrbyCommand(client *c) {
    long long incr;

    if (getLongLongFromObjectOrReply(c, c->argv[2], &incr, NULL) != C_OK) return;
    /* Overflow check: negating LLONG_MIN will cause an overflow */
    if (incr == LLONG_MIN) {
        addReplyError(c, "decrement would overflow");
        return;
    }
    incrDecrCommand(c,-incr);
}

void incrbyfloatCommand(client *c) {
    long double incr, value;

    dictEntryLink link;
    kvobj *o = lookupKeyWriteWithLink(c->db,c->argv[1],&link);
    if (checkType(c,o,OBJ_STRING)) return;
    if (getLongDoubleFromObjectOrReply(c,o,&value,NULL) != C_OK ||
        getLongDoubleFromObjectOrReply(c,c->argv[2],&incr,NULL) != C_OK)
        return;

    value += incr;
    if (isnan(value) || isinf(value)) {
        addReplyError(c,"increment would produce NaN or Infinity");
        return;
    }
    robj *new = createStringObjectFromLongDouble(value,1);
    if (o)
        dbReplaceValueWithLink(c->db, c->argv[1], &new, link);
    else
        dbAddByLink(c->db, c->argv[1], &new, &link);
    keyModified(c,c->db,c->argv[1],new,1);
    notifyKeyspaceEvent(NOTIFY_STRING,"incrbyfloat",c->argv[1],c->db->id);
    server.dirty++;
    addReplyBulk(c,new);

    /* Always replicate INCRBYFLOAT as a SET command with the final value
     * in order to make sure that differences in float precision or formatting
     * will not create differences in replicas or after an AOF restart. */
    rewriteClientCommandArgument(c,0,shared.set);
    rewriteClientCommandArgument(c,2,new);
    rewriteClientCommandArgument(c,3,shared.keepttl);
}

/* INCREX option flags. */
#define OBJ_INCREX_BYFLOAT (1<<0)  /* Set if float-point increment is given */
#define OBJ_INCREX_BYINT   (1<<1)  /* Set if integer increment is given */
#define OBJ_INCREX_LBOUND  (1<<2)  /* Set if lower bound of increx result is given */
#define OBJ_INCREX_UBOUND  (1<<3)  /* Set if upper bound of increx result is given */
#define OBJ_INCREX_SATURATE (1<<4) /* Saturate the result to LBOUND/UBOUND/type limits when out of bounds. */
#define OBJ_INCREX_ENX     (1<<5)  /* Set expiration only when the key has no expiry */
#define OBJ_INCREX_PERSIST (1<<6)  /* Set if we need to remove the ttl */
#define OBJ_INCREX_EX      (1<<7)  /* Set if time in seconds is given */
#define OBJ_INCREX_PX      (1<<8)  /* Set if time in ms is given */
#define OBJ_INCREX_EXAT    (1<<9)  /* Set if timestamp in second is given */
#define OBJ_INCREX_PXAT    (1<<10) /* Set if timestamp in ms is given */

/* INCREX argument structure */
typedef struct {
    int flags;             /* OBJ_INCREX_* bits set during parsing. */
    int unit;              /* UNIT_SECONDS or UNIT_MILLISECONDS for EX/PX/EXAT/PXAT. */
    long long expire_ms;   /* Absolute expire timestamp in ms (0 if no expiration given). */
    long long incr_ll;     /* BYINT increment value (defaults to 1). */
    long long ub_ll;       /* BYINT upper bound (defaults to LLONG_MAX). */
    long long lb_ll;       /* BYINT lower bound (defaults to LLONG_MIN). */
    long double incr_ld;   /* BYFLOAT increment value (defaults to 0). */
    long double ub_ld;     /* BYFLOAT upper bound (defaults to LDBL_MAX). */
    long double lb_ld;     /* BYFLOAT lower bound (defaults to -LDBL_MAX). */
} incrExArgs;

/* The parseIncrExArgumentsOrReply() function performs validation for INCREX command.
 * If there are any syntax violations C_ERR is returned else C_OK is returned. */
static int parseIncrExArgumentsOrReply(client *c, int start_pos, incrExArgs *args) {
    memset(args, 0, sizeof(*args));
    args->unit = UNIT_SECONDS;
    args->incr_ll = 1;
    args->lb_ll = LLONG_MIN;
    args->ub_ll = LLONG_MAX;
    args->lb_ld = -LDBL_MAX;
    args->ub_ld = LDBL_MAX;

    /* LBOUND/UBOUND values are parsed after the loop because their target type
     * depends on whether BYINT or BYFLOAT was given, which may appear later. */
    robj *lower_bound = NULL, *upper_bound = NULL, *expire = NULL;

    /* Mask of all mutually-exclusive expiration-related flags. */
    const int expire_flags = OBJ_INCREX_EX|OBJ_INCREX_PX|OBJ_INCREX_EXAT|OBJ_INCREX_PXAT|OBJ_INCREX_PERSIST;

    for (int j = start_pos; j < c->argc; j++) {
        char *opt = c->argv[j]->ptr;
        robj *next = (j == c->argc-1) ? NULL : c->argv[j+1];

        if (!strcasecmp(opt, "BYINT") && next && !(args->flags & (OBJ_INCREX_BYINT|OBJ_INCREX_BYFLOAT))) {
            if (getLongLongFromObjectOrReply(c, next, &args->incr_ll,
                    "Increment is not an integer or out of range") != C_OK)
            {
                return C_ERR;
            }
            args->flags |= OBJ_INCREX_BYINT;
            j++;
        } else if (!strcasecmp(opt, "BYFLOAT") && next && !(args->flags & (OBJ_INCREX_BYINT|OBJ_INCREX_BYFLOAT))) {
            if (getLongDoubleFromObjectOrReply(c, next, &args->incr_ld,
                    "Increment is not a valid float") != C_OK)
            {
                return C_ERR;
            }
            if (isinf(args->incr_ld)) {
                addReplyError(c, "BYFLOAT increment cannot be Infinity");
                return C_ERR;
            }
            args->flags |= OBJ_INCREX_BYFLOAT;
            j++;
        } else if (!strcasecmp(opt, "LBOUND") && next && !(args->flags & OBJ_INCREX_LBOUND)) {
            args->flags |= OBJ_INCREX_LBOUND;
            lower_bound = next;
            j++;
        } else if (!strcasecmp(opt, "UBOUND") && next && !(args->flags & OBJ_INCREX_UBOUND)) {
            args->flags |= OBJ_INCREX_UBOUND;
            upper_bound = next;
            j++;
        } else if (!strcasecmp(opt, "SATURATE") && !(args->flags & OBJ_INCREX_SATURATE)) {
            args->flags |= OBJ_INCREX_SATURATE;
        } else if (!strcasecmp(opt, "ENX") && !(args->flags & (OBJ_INCREX_ENX|OBJ_INCREX_PERSIST))) {
            args->flags |= OBJ_INCREX_ENX;
        } else if (!strcasecmp(opt, "PERSIST") && !(args->flags & (expire_flags|OBJ_INCREX_ENX))) {
            args->flags |= OBJ_INCREX_PERSIST;
        } else if (!strcasecmp(opt, "EX") && !(args->flags & expire_flags) && next) {
            args->flags |= OBJ_INCREX_EX;
            expire = next;
            j++;
        } else if (!strcasecmp(opt, "PX") && !(args->flags & expire_flags) && next) {
            args->flags |= OBJ_INCREX_PX;
            args->unit = UNIT_MILLISECONDS;
            expire = next;
            j++;
        } else if (!strcasecmp(opt, "EXAT") && !(args->flags & expire_flags) && next) {
            args->flags |= OBJ_INCREX_EXAT;
            expire = next;
            j++;
        } else if (!strcasecmp(opt, "PXAT") && !(args->flags & expire_flags) && next) {
            args->flags |= OBJ_INCREX_PXAT;
            args->unit = UNIT_MILLISECONDS;
            expire = next;
            j++;
        } else {
            addReplyErrorObject(c, shared.syntaxerr);
            return C_ERR;
        }
    }

    /* Resolve LBOUND/UBOUND values now that BYINT/BYFLOAT is known. */
    if (args->flags & OBJ_INCREX_BYFLOAT) {
        if (lower_bound && getLongDoubleFromObjectOrReply(c, lower_bound, &args->lb_ld,
                "LBOUND is not a valid float") != C_OK)
        {
            return C_ERR;
        }
        if (upper_bound && getLongDoubleFromObjectOrReply(c, upper_bound, &args->ub_ld,
                "UBOUND is not a valid float") != C_OK)
        {
            return C_ERR;
        }
        if (args->lb_ld > args->ub_ld) {
            addReplyError(c, "LBOUND can't be greater than UBOUND");
            return C_ERR;
        }
    } else {
        if (lower_bound && getLongLongFromObjectOrReply(c, lower_bound, &args->lb_ll,
                "LBOUND is not an integer or out of range") != C_OK)
        {
            return C_ERR;
        }
        if (upper_bound && getLongLongFromObjectOrReply(c, upper_bound, &args->ub_ll,
                "UBOUND is not an integer or out of range") != C_OK)
        {
            return C_ERR;
        }
        if (args->lb_ll > args->ub_ll) {
            addReplyError(c, "LBOUND can't be greater than UBOUND");
            return C_ERR;
        }
    }

    /* ENX requires an expiration option. */
    if ((args->flags & OBJ_INCREX_ENX) && !(args->flags & expire_flags)) {
        addReplyError(c, "ENX flag requires an expiration");
        return C_ERR;
    }

    if (expire) {
        int relative_ttl = (args->flags & (OBJ_INCREX_EX|OBJ_INCREX_PX)) != 0;
        if (getExpireMillisecondsOrReply(c, expire, relative_ttl, args->unit, &args->expire_ms) != C_OK)
            return C_ERR;
    }
    return C_OK;
}

/*
 * INCREX <key> [BYFLOAT increment | BYINT increment] [LBOUND lowerbound]
 *   [UBOUND upperbound] [SATURATE]
 *   [EX seconds | PX milliseconds | EXAT seconds-timestamp | PXAT milliseconds-timestamp | PERSIST] [ENX]
 *
 * Increments the numeric value of a key and optionally updates its expiration time.
 *
 * Increment options:
 * Defaults to incrementing by 1 (like INCR) if no increment option is given.
 * At most one of the following may be specified:
 * - BYINT:   Increment by an integer (like INCRBY).
 * - BYFLOAT: Increment by a float (like INCRBYFLOAT). Returns an error if the result is NaN or Infinity.
 *
 * Range options:
 * LBOUND and UBOUND optionally restrict the result to a range. The behavior
 * when the result would land outside that range (or, with no explicit bound,
 * would overflow the type limits) is controlled by SATURATE:
 * - Default:    the operation is rejected (the key value and TTL are left
 *               unchanged) and the reply is the current value with an applied
 *               increment of 0.
 * - SATURATE:   the result is capped at UBOUND / floored at LBOUND (or
 *               saturated to the type limits when no explicit bound is given)
 *               instead of being rejected.
 *
 * Expiration options:
 * At most one of the following may be specified:
 * - EX:      Set expiration in seconds.
 * - PX:      Set expiration in milliseconds.
 * - EXAT:    Set expiration to an absolute Unix timestamp (seconds).
 * - PXAT:    Set expiration to an absolute Unix timestamp (milliseconds).
 * - PERSIST: Remove the key's TTL.
 *
 * If no expiration option is given, the key's existing TTL is preserved.
 * ENX restricts expiration updates to keys that currently have no TTL.
 *
 * Reply:
 * - (Array) of two Bulk Strings on success:
 *   1. The new value of the key after the increment.
 *   2. The actual increment applied.
 *
 * Note: When the result is saturated by LBOUND/UBOUND, the expiration is still updated normally.
 */
void increxCommand(client *c) {
    kvobj *o = NULL;
    robj *new = NULL;
    dictEntryLink link;
    long long value_ll, oldvalue_ll = 0;
    long double value_ld, oldvalue_ld = 0;

    incrExArgs args;
    if (parseIncrExArgumentsOrReply(c, 2, &args) != C_OK)
        return;

    o = lookupKeyWriteWithLink(c->db, c->argv[1], &link);
    if (checkType(c, o, OBJ_STRING)) return;

    int byfloat = args.flags & OBJ_INCREX_BYFLOAT;
    /* By default the operation is rejected on out-of-bounds:
     * leave the key unchanged and reply [current_value, 0]. */
    int sat_mode = args.flags & OBJ_INCREX_SATURATE;
    if (byfloat) {
        long double lb = args.lb_ld, ub = args.ub_ld;
        if (getLongDoubleFromObjectOrReply(c, o, &value_ld, NULL) != C_OK)
            return;

        /* Reject if the existing value is already Infinity (the increment is
         * checked at parse time in parseIncrExArgumentsOrReply). */
        if (isinf(value_ld)) {
            addReplyError(c, "value cannot be Infinity");
            return;
        }

        oldvalue_ld = value_ld;
        value_ld += args.incr_ld;
        int overflow = isinf(value_ld);
        if (overflow || value_ld > ub || value_ld < lb) {
            /* Result is infinite or out of [LBOUND, UBOUND]:
             * default: reject (leave key untouched, reply [current_value, 0]);
             * SATURATE: clamp to +/-LDBL_MAX or the breached bound. */
            if (!sat_mode) {
                addReplyArrayLen(c, 2);
                addReplyHumanLongDouble(c, oldvalue_ld);
                addReplyHumanLongDouble(c, 0);
                return;
            }

            /* SATURATE: clamp the result. */
            if (overflow)
                value_ld = (args.incr_ld >= 0) ? ub : lb;
            else
                value_ld = value_ld > ub ? ub : lb;
        }

        long double delta = value_ld - oldvalue_ld;
        if (isinf(delta)) {
            /* The applied delta cannot be represented as a valid long double. This can
             * only happen under SATURATE when the saturated result and the
             * prior value sit at opposite ends of the type range. */
            addReplyError(c, "applied increment would be Infinity");
            return;
        }

        addReplyArrayLen(c, 2);
        addReplyHumanLongDouble(c, value_ld);
        addReplyHumanLongDouble(c, delta);
    } else {
        long long lb = args.lb_ll, ub = args.ub_ll;
        if (getLongLongFromObjectOrReply(c, o, &value_ll, NULL) != C_OK)
            return;

        oldvalue_ll = value_ll;
        int overflow = add_overflow_ll(oldvalue_ll, args.incr_ll, &value_ll);
        if (overflow || value_ll > ub || value_ll < lb) {
            /* Result overflows long long or is out of [LBOUND, UBOUND]:
             * default: reject (leave key untouched, reply [current_value, 0]);
             * SATURATE: clamp to LLONG_MAX/LLONG_MIN or the breached bound. */
            if (!sat_mode) {
                addReplyArrayLen(c, 2);
                addReplyLongLong(c, oldvalue_ll);
                addReplyLongLong(c, 0);
                return;
            }

            /* SATURATE: clamp the result. */
            if (overflow)
                value_ll = (args.incr_ll >= 0) ? ub : lb;
            else
                value_ll = value_ll > ub ? ub : lb;
        }

        long long delta = 0;
        if (sub_overflow_ll(value_ll, oldvalue_ll, &delta)) {
            /* The applied delta cannot be represented as a long long. This can
             * only happen under SATURATE when the saturated result and the
             * prior value sit at opposite ends of the type range. */
            addReplyError(c, "applied increment would overflow");
            return;
        }

        addReplyArrayLen(c, 2);
        addReplyLongLong(c, value_ll);
        addReplyLongLong(c, delta);
    }

    /* If the expire time is already elapsed, it is propagated as DEL/UNLINK */
    int has_expiry = o && (kvobjGetExpire(o) != -1);
    int set_new_expire = args.expire_ms && (!(args.flags & OBJ_INCREX_ENX) || !has_expiry);
    if (set_new_expire && checkAlreadyExpired(args.expire_ms)) {
        if (o) {
            int deleted = dbGenericDelete(c->db, c->argv[1], server.lazyfree_lazy_expire, DB_FLAG_KEY_EXPIRED);
            serverAssert(deleted);
            robj *aux = server.lazyfree_lazy_expire ? shared.unlink : shared.del;
            rewriteClientCommandVector(c, 2, aux, c->argv[1]);
            keyModified(c, c->db, c->argv[1], NULL, 1);
            notifyKeyspaceEvent(NOTIFY_GENERIC, "del", c->argv[1], c->db->id);
            server.dirty++;
        }
        server.stat_expiredkeys++;
        return;
    }

    if (!byfloat && o && o->refcount == 1 && o->encoding == OBJ_ENCODING_INT &&
        value_ll >= LONG_MIN && value_ll <= LONG_MAX)
    {
        new = o;
        o->ptr = (void*)((long)value_ll);
        updateKeysizesHist(c->db, OBJ_STRING, (int64_t)sdigits10(oldvalue_ll), (int64_t)sdigits10(value_ll));
    } else {
        if (byfloat)
            new = createStringObjectFromLongDouble(value_ld, 1);
        else
            new = createStringObjectFromLongLongForValue(value_ll);
        if (o)
            dbReplaceValueWithLink(c->db, c->argv[1], &new, link);
        else
            dbAddByLink(c->db, c->argv[1], &new, &link);
    }

    /* Replicate INCREX as SET with the final value to avoid float precision
     * or formatting drift across replicas / AOF restart. The TTL clause is:
     *   PERSIST          -> SET <key> <result>
     *   sets a new TTL   -> SET <key> <result> PXAT <timestamp>
     *   otherwise        -> SET <key> <result> KEEPTTL  (no expire option,
     *                       or ENX hit on a key that already has a TTL) */
    int persist_notify = 0, expire_notify = 0;
    if (args.flags & OBJ_INCREX_PERSIST) {
        persist_notify = removeExpire(c->db, c->argv[1]);
        rewriteClientCommandVector(c, 3, shared.set, c->argv[1], new);
    } else if (set_new_expire) {
        new = setExpire(c, c->db, c->argv[1], args.expire_ms);
        expire_notify = 1;
        robj *milliseconds_obj = createStringObjectFromLongLong(args.expire_ms);
        rewriteClientCommandVector(c, 5, shared.set, c->argv[1], new, shared.pxat, milliseconds_obj);
        decrRefCount(milliseconds_obj);
    } else {
        rewriteClientCommandVector(c, 4, shared.set, c->argv[1], new, shared.keepttl);
    }

    keyModified(c, c->db, c->argv[1], new, 1);
    server.dirty++;

    notifyKeyspaceEvent(NOTIFY_STRING, byfloat ? "incrbyfloat" : "incrby", c->argv[1], c->db->id);
    if (persist_notify)
        notifyKeyspaceEvent(NOTIFY_GENERIC, "persist", c->argv[1], c->db->id);
    if (expire_notify)
        notifyKeyspaceEvent(NOTIFY_GENERIC, "expire", c->argv[1], c->db->id);

    /* A KSN handler may reallocate the kvobj and replace it in the dict. The local
     * pointers `o`/`new` may then point to a stale object and must not be dereferenced;
     * null them out. The object is not freed though if rewriteClientCommandVector()
     * above incremented its refcount, so c->argv keeps it alive for command propagation. */
    KSN_INVALIDATE_KVOBJ(o);
    KSN_INVALIDATE_KVOBJ(new);
}

void appendCommand(client *c) {
    size_t totlen;
    robj *append;
    kvobj *o;
    size_t oldsize = 0;

    dictEntryLink link;
    o = lookupKeyWriteWithLink(c->db,c->argv[1],&link);
    if (o == NULL) {
        /* Create the key */
        c->argv[2] = tryObjectEncoding(c->argv[2]);
        o = dbAddByLink(c->db, c->argv[1], &c->argv[2], &link);
        incrRefCount(c->argv[2]);
        totlen = stringObjectLen(c->argv[2]);
    } else {
        /* Key exists, check type */
        if (checkType(c,o,OBJ_STRING))
            return;

        /* "append" is an argument, so always an sds */
        append = c->argv[2];
        size_t append_len = sdslen(append->ptr);
        if (checkStringLength(c,stringObjectLen(o),append_len) != C_OK)
            return;

        /* Append the value */
        o = dbUnshareStringValueByLink(c->db,c->argv[1],o,link);
        if (server.memory_tracking_enabled)
            oldsize = kvobjAllocSize(o);
        o->ptr = sdscatlen(o->ptr,append->ptr,append_len);
        if (server.memory_tracking_enabled)
            updateSlotAllocSize(c->db, getKeySlot(c->argv[1]->ptr), o, oldsize, kvobjAllocSize(o));
        totlen = sdslen(o->ptr);
        int64_t oldlen = totlen - append_len;
        updateKeysizesHist(c->db, OBJ_STRING, oldlen, totlen);
    }
    keyModified(c,c->db,c->argv[1],o,1);
    notifyKeyspaceEvent(NOTIFY_STRING,"append",c->argv[1],c->db->id);
    server.dirty++;

    addReplyLongLong(c,totlen);
}

void strlenCommand(client *c) {
    kvobj *kv;
    if ((kv = lookupKeyReadOrReply(c, c->argv[1], shared.czero)) == NULL ||
        checkType(c, kv, OBJ_STRING)) return;
    addReplyLongLong(c,stringObjectLen(kv));
}

/* LCS key1 key2 [LEN] [IDX] [MINMATCHLEN <len>] [WITHMATCHLEN] */
void lcsCommand(client *c) {
    uint32_t i, j;
    long long minmatchlen = 0;
    sds a = NULL, b = NULL;
    int getlen = 0, getidx = 0, withmatchlen = 0;

    kvobj *obja = lookupKeyRead(c->db, c->argv[1]);
    kvobj *objb = lookupKeyRead(c->db, c->argv[2]);
    if ((obja && obja->type != OBJ_STRING) ||
        (objb && objb->type != OBJ_STRING))
    {
        addReplyError(c,
            "The specified keys must contain string values");
        /* Don't cleanup the objects, we need to do that
         * only after calling getDecodedObject(). */
        obja = NULL;
        objb = NULL;
        goto cleanup;
    }
    obja = obja ? getDecodedObject(obja) : createStringObject("",0);
    objb = objb ? getDecodedObject(objb) : createStringObject("",0);
    a = obja->ptr;
    b = objb->ptr;

    for (j = 3; j < (uint32_t)c->argc; j++) {
        char *opt = c->argv[j]->ptr;
        int moreargs = (c->argc-1) - j;

        if (!strcasecmp(opt,"IDX")) {
            getidx = 1;
        } else if (!strcasecmp(opt,"LEN")) {
            getlen = 1;
        } else if (!strcasecmp(opt,"WITHMATCHLEN")) {
            withmatchlen = 1;
        } else if (!strcasecmp(opt,"MINMATCHLEN") && moreargs) {
            if (getLongLongFromObjectOrReply(c,c->argv[j+1],&minmatchlen,NULL)
                != C_OK) goto cleanup;
            if (minmatchlen < 0) minmatchlen = 0;
            j++;
        } else {
            addReplyErrorObject(c,shared.syntaxerr);
            goto cleanup;
        }
    }

    /* Complain if the user passed ambiguous parameters. */
    if (getlen && getidx) {
        addReplyError(c,
            "If you want both the length and indexes, please just use IDX.");
        goto cleanup;
    }

    /* Detect string truncation or later overflows. */
    if (sdslen(a) >= UINT32_MAX-1 || sdslen(b) >= UINT32_MAX-1) {
        addReplyError(c, "String too long for LCS");
        goto cleanup;
    }

    /* Compute the LCS using the vanilla dynamic programming technique of
     * building a table of LCS(x,y) substrings. */
    uint32_t alen = sdslen(a);
    uint32_t blen = sdslen(b);

    /* Setup an uint32_t array to store at LCS[i,j] the length of the
     * LCS A0..i-1, B0..j-1. Note that we have a linear array here, so
     * we index it as LCS[j+(blen+1)*i] */
    #define LCS(A,B) lcs[(B)+((A)*(blen+1))]

    /* Try to allocate the LCS table, and abort on overflow or insufficient memory. */
    unsigned long long lcssize = (unsigned long long)(alen+1)*(blen+1); /* Can't overflow due to the size limits above. */
    unsigned long long lcsalloc = lcssize * sizeof(uint32_t);
    uint32_t *lcs = NULL;
    if (lcsalloc < SIZE_MAX && lcsalloc / lcssize == sizeof(uint32_t)) {
        if (lcsalloc > (size_t)server.proto_max_bulk_len) {
            addReplyError(c, "Insufficient memory, transient memory for LCS exceeds proto-max-bulk-len");
            goto cleanup;
        }
        lcs = ztrymalloc(lcsalloc);
    }
    if (!lcs) {
        addReplyError(c, "Insufficient memory, failed allocating transient memory for LCS");
        goto cleanup;
    }

    /* Start building the LCS table. */
    for (uint32_t i = 0; i <= alen; i++) {
        for (uint32_t j = 0; j <= blen; j++) {
            if (i == 0 || j == 0) {
                /* If one substring has length of zero, the
                 * LCS length is zero. */
                LCS(i,j) = 0;
            } else if (a[i-1] == b[j-1]) {
                /* The len LCS (and the LCS itself) of two
                 * sequences with the same final character, is the
                 * LCS of the two sequences without the last char
                 * plus that last char. */
                LCS(i,j) = LCS(i-1,j-1)+1;
            } else {
                /* If the last character is different, take the longest
                 * between the LCS of the first string and the second
                 * minus the last char, and the reverse. */
                uint32_t lcs1 = LCS(i-1,j);
                uint32_t lcs2 = LCS(i,j-1);
                LCS(i,j) = lcs1 > lcs2 ? lcs1 : lcs2;
            }
        }
    }

    /* Store the actual LCS string in "result" if needed. We create
     * it backward, but the length is already known, we store it into idx. */
    uint32_t idx = LCS(alen,blen);
    sds result = NULL;        /* Resulting LCS string. */
    void *arraylenptr = NULL; /* Deferred length of the array for IDX. */
    uint32_t arange_start = alen, /* alen signals that values are not set. */
             arange_end = 0,
             brange_start = 0,
             brange_end = 0;

    /* Do we need to compute the actual LCS string? Allocate it in that case. */
    int computelcs = getidx || !getlen;
    if (computelcs) result = sdsnewlen(SDS_NOINIT,idx);

    /* Start with a deferred array if we have to emit the ranges. */
    uint32_t arraylen = 0;  /* Number of ranges emitted in the array. */
    if (getidx) {
        addReplyMapLen(c,2);
        addReplyBulkCString(c,"matches");
        arraylenptr = addReplyDeferredLen(c);
    }

    i = alen, j = blen;
    while (computelcs && i > 0 && j > 0) {
        int emit_range = 0;
        if (a[i-1] == b[j-1]) {
            /* If there is a match, store the character and reduce
             * the indexes to look for a new match. */
            result[idx-1] = a[i-1];

            /* Track the current range. */
            if (arange_start == alen) {
                arange_start = i-1;
                arange_end = i-1;
                brange_start = j-1;
                brange_end = j-1;
            } else {
                /* Let's see if we can extend the range backward since
                 * it is contiguous. */
                if (arange_start == i && brange_start == j) {
                    arange_start--;
                    brange_start--;
                } else {
                    emit_range = 1;
                }
            }
            /* Emit the range if we matched with the first byte of
             * one of the two strings. We'll exit the loop ASAP. */
            if (arange_start == 0 || brange_start == 0) emit_range = 1;
            idx--; i--; j--;
        } else {
            /* Otherwise reduce i and j depending on the largest
             * LCS between, to understand what direction we need to go. */
            uint32_t lcs1 = LCS(i-1,j);
            uint32_t lcs2 = LCS(i,j-1);
            if (lcs1 > lcs2)
                i--;
            else
                j--;
            if (arange_start != alen) emit_range = 1;
        }

        /* Emit the current range if needed. */
        uint32_t match_len = arange_end - arange_start + 1;
        if (emit_range) {
            if (minmatchlen == 0 || match_len >= minmatchlen) {
                if (arraylenptr) {
                    addReplyArrayLen(c,2+withmatchlen);
                    addReplyArrayLen(c,2);
                    addReplyLongLong(c,arange_start);
                    addReplyLongLong(c,arange_end);
                    addReplyArrayLen(c,2);
                    addReplyLongLong(c,brange_start);
                    addReplyLongLong(c,brange_end);
                    if (withmatchlen) addReplyLongLong(c,match_len);
                    arraylen++;
                }
            }
            arange_start = alen; /* Restart at the next match. */
        }
    }

    /* Signal modified key, increment dirty, ... */

    /* Reply depending on the given options. */
    if (arraylenptr) {
        addReplyBulkCString(c,"len");
        addReplyLongLong(c,LCS(alen,blen));
        setDeferredArrayLen(c,arraylenptr,arraylen);
    } else if (getlen) {
        addReplyLongLong(c,LCS(alen,blen));
    } else {
        addReplyBulkSds(c,result);
        result = NULL;
    }

    /* Cleanup. */
    sdsfree(result);
    zfree(lcs);

cleanup:
    if (obja) decrRefCount(obja);
    if (objb) decrRefCount(objb);
    return;
}

/* Validate that a digest string has the correct length (DIGEST_HEX_LENGTH characters).
 * Note: This only validates length, not whether characters are valid hex digits.
 * Invalid hex characters will simply fail to match during comparison.
 * Returns C_OK if length is correct, C_ERR otherwise. */
int validateHexDigest(client *c, const sds digest) {
    size_t len = sdslen(digest);
    if (len != DIGEST_HEX_LENGTH) {
        addReplyErrorFormat(c, "must be exactly %d hexadecimal characters", DIGEST_HEX_LENGTH);
        return C_ERR;
    }
    return C_OK;
}

/* Return the xxh3 hash of a string object as a hex string stored in an sds.
 * The user is responsible for freeing the sds. */
sds stringDigest(robj *o) {
    serverAssert(o && o->type == OBJ_STRING);

    XXH64_hash_t hash = 0;
    if (sdsEncodedObject(o)) {
        hash = XXH3_64bits(o->ptr, sdslen(o->ptr));
    } else if (o->encoding == OBJ_ENCODING_INT) {
        char buf[LONG_STR_SIZE];
        size_t len = ll2string(buf,sizeof(buf),(long)o->ptr);
        hash = XXH3_64bits(buf, len);
    } else {
        serverPanic("Wrong obj->encoding stringDigest()");
    }

    sds hexhash = sdsempty();
    hexhash = sdscatprintf(hexhash, "%0" STRINGIFY(DIGEST_HEX_LENGTH) PRIx64, hash);
    return hexhash;
}

/* DIGEST key
 *
 * Return digest of the key's value computed via XXH3 hash. The key must be a
 * STRING object. */
void digestCommand(client *c) {
    kvobj *o;

    if ((o = lookupKeyReadOrReply(c, c->argv[1], shared.null[c->resp])) == NULL)
        return;

    if (checkType(c,o,OBJ_STRING))
        return;

    addReplyBulkSds(c, stringDigest(o));
}

